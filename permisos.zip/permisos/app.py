from flask import Flask, request, redirect, url_for, render_template
from pymongo import MongoClient
from bson import ObjectId
from datetime import datetime

app = Flask(__name__)

# Conexión MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["base"]
collection = db["permisos"]


def user_serializer(user) -> dict:
    fecha = user.get("fecha", "")
    if isinstance(fecha, datetime):
        fecha = fecha.strftime("%Y-%m-%d")
    return {
        "id": str(user["_id"]),
        "tipo": TIPO_MAP.get(user.get("tipo", ""), user.get("tipo", "")),
        "fecha": fecha,
        "obs": user.get("obs", "")
    }

TIPO_MAP = {
    "vaca": "Vacaciones",
    "dos": "Dos Horas",
    "eco": "Economico"
}

# Página principal: lista de usuarios
@app.route("/")
def index():
    usuarios = [user_serializer(u) for u in collection.find()]
    return render_template("index.html", usuarios=usuarios)

# Crear usuario (form POST)
@app.route("/agregar", methods=["POST"])
def agregar():
    tipo = request.form.get("tipo")
    fecha_str = request.form.get("fecha")   # "YYYY-MM-DD"
    obs = request.form.get("obs")
    if tipo and fecha_str and obs:
        # convertir a datetime (hora 00:00:00)
        fecha_dt = datetime.strptime(fecha_str, "%Y-%m-%d")
        collection.insert_one({"tipo": tipo, "fecha": fecha_dt, "obs": obs})
    return redirect(url_for("index"))


@app.route("/agregarx", methods=["POST"])
def agregarx():
    tipo = request.form.get("tipo")
    fecha = request.form.get("fecha")
    obs = request.form.get("obs")
    if tipo and fecha and obs:
        collection.insert_one({"tipo": tipo, "fecha": fecha, "obs": obs})
    return redirect(url_for("index"))

# Eliminar usuario
@app.route("/eliminar/<id>")
def eliminar(id):
    collection.delete_one({"_id": ObjectId(id)})
    return redirect(url_for("index"))


@app.route("/reporte")
def reporte():
    # Obtener fechas de la URL ?inicio=2025-10-01&fin=2025-10-10
    inicio_str = request.args.get("inicio")
    fin_str = request.args.get("fin")

    filtro = {}
    if inicio_str and fin_str:
        inicio = datetime.strptime(inicio_str, "%Y-%m-%d")
        fin = datetime.strptime(fin_str, "%Y-%m-%d")
        # Ajustar el rango para incluir todo el día final
        fin = fin.replace(hour=23, minute=59, second=59)
        filtro["fecha"] = {"$gte": inicio, "$lte": fin}

    pipeline = [
        {"$match": filtro} if filtro else {},  # aplicar solo si hay filtro
        {
            "$group": {
                "_id": "$tipo",
                "total": { "$sum": 1 }
            }
        }
    ]
    # limpiar el pipeline si no hay filtro (evitar dict vacío)
    pipeline = [p for p in pipeline if p]

    resultado = list(collection.aggregate(pipeline))
    data = [{"tipo": TIPO_MAP.get(r["_id"], r["_id"]), "total": r["total"]} for r in resultado]
    return render_template("reporte.html", data=data, inicio=inicio_str, fin=fin_str)

# Reporte de tipo
@app.route("/reportex")
def reportex():
    pipeline = [
        {
            "$group": {
                "_id": "$tipo",   # usamos el campo directamente
                "total": { "$sum": 1 }
            }
        }
    ]
    resultado = list(collection.aggregate(pipeline))
    #data = [{"tipo": r["_id"], "total": r["total"]} for r in resultado]
    data = [{"tipo": TIPO_MAP.get(r["_id"], r["_id"]), "total": r["total"]} for r in resultado]
    return render_template("reporte.html", data=data)


if __name__ == "__main__":
    app.run(debug=True)


